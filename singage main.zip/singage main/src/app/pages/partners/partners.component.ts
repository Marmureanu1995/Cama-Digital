import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-partners',
  templateUrl: './partners.component.html',
  styleUrls: ['./partners.component.scss'],
})
export class PartnersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
