import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.scss'],
})
export class CompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
