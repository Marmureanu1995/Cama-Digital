export class UserStatistics{
    hexCode:string;
    isOnline:boolean;
    lastContacted:string;
    playerVersion:string;
}