export class screenshotModel{
    screenshotNumber:number;
    url:string;
    takeScreenShot:boolean;
}