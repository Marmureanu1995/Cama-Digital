export class MediaFolder {
    id: string;
    user_id: string;
    name: string;
  }
  